import { File, ProcessCloseReason } from 'clientnode/type';
import { PluginAPI } from 'web-node';
import { Plugin, PluginHandler } from 'web-node/type';
import { Configuration, Services } from './type';
/**
 * Provides a pre-rendering hook for webNode applications.
 */
export declare class PreRender implements PluginHandler {
    /**
     * Triggered hook when at least one plugin has a new configuration file and
     * configuration object has been changed.
     * @param configuration - Updated configuration object.
     * @param pluginsWithChangedConfiguration - List of plugins which have a
     * changed plugin configuration.
     * @param plugins - List of all loaded plugins.
     * @param pluginAPI - Plugin api reference.
     *
     * @returns New configuration object to use.
     */
    static postConfigurationLoaded(configuration: Configuration, pluginsWithChangedConfiguration: Array<Plugin>, plugins: Array<Plugin>, pluginAPI: typeof PluginAPI): Promise<Configuration>;
    /**
     * Appends an pre-renderer to the web node services.
     * @param services - An object with stored service instances.
     *
     * @returns Given and extended object of services.
     */
    static preLoadService(services: Services): Services;
    /**
     * Triggers when application will be closed soon and removes created files.
     * @param services - An object with stored service instances.
     * @param configuration - Updated configuration object.
     * @param plugins - List of all loaded plugins.
     * @param pluginAPI - Plugin api reference.
     *
     * @returns Given object of services.
     */
    static shouldExit(services: Services, configuration: Configuration, plugins: Array<Plugin>, pluginAPI: typeof PluginAPI): Promise<Services>;
    /**
     * Retrieves all directories which have a pre-rendered structure.
     * @param configuration - Updated configuration object.
     * @param plugins - List of all loaded plugins.
     * @param pluginAPI - Plugin api reference.
     *
     * @returns A promise holding all resolved file objects.
     */
    static getPrerenderedOutputDirectories(configuration: Configuration, plugins: Array<Plugin>, pluginAPI: typeof PluginAPI): Promise<Array<File>>;
    /**
     * Retrieves all files to process.
     * @param configuration - Updated configuration object.
     * @param plugins - List of all loaded plugins.
     * @param pluginAPI - Plugin api reference.
     *
     * @returns A promise holding all resolved file objects.
     */
    static getPrerendererExecuter(configuration: Configuration, plugins: Array<Plugin>, pluginAPI: typeof PluginAPI): Promise<Array<File>>;
    /**
     * Triggers pre-rendering.
     * @param configuration - Configuration object.
     * @param plugins - List of all loaded plugins.
     * @param pluginAPI - Plugin api reference.
     * @param additionalCLIParameter - List of additional cli parameter to use.
     *
     * @returns A Promise resolving to a list of prerenderer files.
     */
    static render(configuration: Configuration, plugins: Array<Plugin>, pluginAPI: typeof PluginAPI, additionalCLIParameter?: Array<string> | string): Promise<Array<File>>;
    /**
     * Executes given pre-renderer file.
     * @param filePath - File path to execute as pre-renderer.
     * @param cliParameter - List of cli parameter to use.
     *
     * @returns A promise resolving after pre-rendering has finished.
     */
    static renderFile(filePath: string, cliParameter?: Array<string>): Promise<ProcessCloseReason>;
}
export default PreRender;
