import { File, ProcessCloseReason } from 'clientnode/type';
import { PluginAPI } from 'web-node';
import { ChangedConfigurationState, Plugin, PluginHandler } from 'web-node/type';
import { Configuration, ServicesState, State } from './type';
/**
 * Provides a pre-rendering hook for webNode applications.
 */
export declare class PreRender implements PluginHandler {
    /**
     * Triggered hook when at least one plugin has a new configuration file and
     * configuration object has been changed.
     * @param state - Application state.
     *
     * @returns Promise resolving to nothing.
     */
    static postConfigurationHotLoaded(state: ChangedConfigurationState): Promise<void>;
    /**
     * Appends an pre-renderer to the web node services.
     * @param state - Application state.
     *
     * @returns Promise resolving to nothing.
     */
    static preLoadService(state: ServicesState): Promise<void>;
    /**
     * Triggers when application will be closed soon and removes created files.
     * @param state - Application state.
     * @param state.configuration - Applications configuration.
     * @param state.pluginAPI - Applications plugin api.
     * @param state.plugins - Applications plugins.
     * @param state.services - Applications services.
     *
     * @returns Promise resolving to nothing.
     */
    static shouldExit({ configuration, pluginAPI, plugins, services }: State): Promise<void>;
    /**
     * Retrieves all directories which have a pre-rendered structure.
     * @param configuration - Updated configuration object.
     * @param plugins - List of all loaded plugins.
     * @param pluginAPI - Plugin api reference.
     *
     * @returns A promise holding all resolved file objects.
     */
    static getPrerenderedOutputDirectories(configuration: Configuration, plugins: Array<Plugin>, pluginAPI: typeof PluginAPI): Promise<Array<File>>;
    /**
     * Retrieves all files to process.
     * @param configuration - Updated configuration object.
     * @param plugins - List of all loaded plugins.
     * @param pluginAPI - Plugin api reference.
     *
     * @returns A promise holding all resolved file objects.
     */
    static getPrerendererExecuter(configuration: Configuration, plugins: Array<Plugin>, pluginAPI: typeof PluginAPI): Promise<Array<File>>;
    /**
     * Triggers pre-rendering.
     * @param state - Application state.
     *
     * @returns A Promise resolving to nothing.
     */
    static render(state: State<Array<string> | string | undefined>): Promise<void>;
    /**
     * Executes given pre-renderer file.
     * @param filePath - File path to execute as pre-renderer.
     * @param cliParameter - List of cli parameter to use.
     *
     * @returns A promise resolving after pre-rendering has finished.
     */
    static renderFile(filePath: string, cliParameter?: Array<string>): Promise<ProcessCloseReason>;
}
export default PreRender;
